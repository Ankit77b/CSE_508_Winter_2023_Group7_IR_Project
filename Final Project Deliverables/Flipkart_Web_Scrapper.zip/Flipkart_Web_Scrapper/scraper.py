import requests
from bs4 import BeautifulSoup
import spacy
import nltk
import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
from itertools import chain
import re


def preprocessing(string_list):

  # Remove punctuation and symbols
  string_list = [s.translate(str.maketrans('', '', string.punctuation)) for s in string_list]

  # Tokenize the strings
  string_list = [word_tokenize(s) for s in string_list]

  # Remove stop words
  stop_words = set(stopwords.words('english'))
  string_list = [[word for word in s if word.casefold() not in stop_words] for s in string_list]

  # Lemmatize words
  lemmatizer = WordNetLemmatizer()
  string_list = [[lemmatizer.lemmatize(word) for word in s] for s in string_list]

  # Flatten the list of lists to a one-dimensional list
  string_list = list(chain.from_iterable(string_list))
  
  # Output the preprocessed strings
  return string_list


def filter_text(text):
  # remove model numbers and technical specifications
  text = re.sub(r'[a-zA-Z0-9]+IN', '', text)
  text = re.sub(r'\d+μm', '', text)
  text = re.sub(r'([0-9]+\.?[0-9]*|\.[0-9]+)', '', text)

  # remove special characters and punctuations
  text = re.sub(r'[^\w\s]', '', text)

  # Define regular expressions for patterns to be removed
  non_contributing_patterns = [r'\b\w{1,2}\b', r'\b\d+\b', r'\b(?:Yes|No)\b']

  # Remove non-contributing patterns from the text
  for pattern in non_contributing_patterns:
    text = re.sub(pattern, '', text)

  # convert text to lowercase
  text = text.lower()

  # tokenize the text into individual words and phrases
  tokens = word_tokenize(text)

  # remove stop words
  stop_words = set(stopwords.words('english'))
  filtered_tokens = [token for token in tokens if token not in stop_words]

  # lemmatize the tokens
  lemmatizer = WordNetLemmatizer()
  lemmatized_tokens = [lemmatizer.lemmatize(token) for token in filtered_tokens]
  pos_tags = nltk.pos_tag(lemmatized_tokens)
  print(pos_tags)

  # Keep only nouns, proper nouns, and adjectives 
  relevant_tags = ['NN', 'NNS', 'NNP', 'NNPS', 'JJ']
  text = ' '.join([word for word, tag in pos_tags if tag in relevant_tags])

  # return the preprocessed text
  return text



def scrape_specifications(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    
    # Find the "Specifications" section of the page
    spec_section = soup.find("div", {"class": "_1UhVsV"})

    # Find all the "li" tags using the find_all() method
    li_tags = spec_section.find_all('li')

    # Find all the "div" tags that have the attribute name using the find_all() method
    all_attributes = spec_section.find_all("td", {"class": "_1hKmbr col col-3-12"})

    # Extract the attribute names and contents
    attributes = [att.get_text().strip() for att in all_attributes]
    li_content = [li.get_text().strip() for li in li_tags]

    # Concatenate the list items into a string
    concatenated_list = [s.replace(',', '') for s in li_content]
    final_text = ' '.join(concatenated_list)

    # Preprocess the text
    preprocessed_list = preprocessing([final_text])
    filtered_text = filter_text(preprocessed_list[0])

    # Find the image tag and get the image URLs
    image_tags = soup.find_all("img", {"class": "_396cs4 _2amPTt _3qGmMb"})
    image_urls = [image_tag['src'] for image_tag in image_tags]

    # Output the results
    # print('Scraped URL:', url)
    # print('---------------------------------------------')
    data = {}
    for i in range(len(attributes)):
        data[attributes[i]] =  li_content[i]

    data['image_urls'] = image_urls
    return data#{"data": data, "image_urls": image_urls}
    # print('---------------------------------------------')
    # print('Filtered text:')
    # print(filtered_text)

    # return filtered_text, attributes, li_content
