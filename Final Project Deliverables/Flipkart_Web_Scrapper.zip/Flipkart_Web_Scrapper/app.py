from flask import Flask, request, render_template
from scraper import scrape_specifications

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        # Insert your web scraping code here to get the dictionary from the URL
        result = scrape_specifications(url)
        return render_template('scrape.html', result=result)
    return render_template('index.html')

if __name__ == '__main__':
    app.run()
